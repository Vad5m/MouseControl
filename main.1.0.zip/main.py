from flask import Flask, render_template_string, request
import socket
import uinput
import time
from threading import Thread

app = Flask(__name__)

# Создаём виртуальную мышь с поддержкой колёсика
try:
    device = uinput.Device([
        uinput.REL_X, uinput.REL_Y,
        uinput.REL_WHEEL,
        uinput.BTN_LEFT, uinput.BTN_RIGHT
    ])
    print("Виртуальное устройство мыши создано успешно.")
except Exception as e:
    print(f"Ошибка создания виртуального устройства: {e}")
    print("Убедитесь, что вы добавили пользователя в группу 'input' и перезашли в систему.")
    exit(1)

# Очереди
move_queue = []
scroll_queue = []

def move_worker():
    while True:
        if move_queue:
            dx, dy = move_queue.pop(0)
            if dx != 0:
                device.emit(uinput.REL_X, int(dx))
            if dy != 0:
                device.emit(uinput.REL_Y, int(dy))
            time.sleep(0.005)
        elif scroll_queue:
            delta = scroll_queue.pop(0)
            if delta != 0:
                device.emit(uinput.REL_WHEEL, int(delta))
                time.sleep(0.005)
        else:
            time.sleep(0.001)

Thread(target=move_worker, daemon=True).start()

def click_left():
    device.emit(uinput.BTN_LEFT, 1)
    time.sleep(0.05)
    device.emit(uinput.BTN_LEFT, 0)

def click_right():
    device.emit(uinput.BTN_RIGHT, 1)
    time.sleep(0.05)
    device.emit(uinput.BTN_RIGHT, 0)

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Mouse Control</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            user-select: none;
            touch-action: none;
        }
        body {
            background: #0a0a0a;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
        }
        .container {
            width: 100%;
            height: 100%;
            max-width: 500px;
            background: #1a1a1a;
            display: flex;
            flex-direction: column;
            padding: 20px;
            gap: 20px;
        }
        .touchpad {
            flex: 1;
            background: #2c2c2e;
            border-radius: 28px;
            touch-action: none;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        .buttons {
            display: flex;
            gap: 20px;
        }
        button {
            flex: 1;
            aspect-ratio: 1 / 1;
            background: #3a3a3c;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.1s ease;
        }
        button:active {
            background: #5a5a5c;
            transform: scale(0.96);
        }
        .status {
            text-align: center;
            color: #888;
            font-size: 12px;
            margin-top: 8px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="touchpad" id="touchpad"></div>
    <div class="buttons">
        <button id="leftBtn"></button>
        <button id="rightBtn"></button>
    </div>
    <div class="status" id="status">⚡ тап 1 палец → левый клик | 2 пальца → скролл</div>
</div>

<script>
    let lastX = null, lastY = null;
    let lastSendTime = 0;
    const MIN_INTERVAL = 10;

    // Для определения тапов (одинарный/двойной)
    let tapTimeout = null;
    let lastTapTime = 0;
    let isTapPending = false;
    let startTapX = 0, startTapY = 0;
    let isMovingDuringTap = false;

    // Для двух пальцев (скролл)
    let twoFingerStartY = null;
    let twoFingerActive = false;
    let lastScrollY = null;

    const touchpad = document.getElementById('touchpad');
    const statusDiv = document.getElementById('status');

    touchpad.addEventListener('touchstart', function(e) {
        e.preventDefault();
        const rect = touchpad.getBoundingClientRect();
        const touches = e.touches;

        if (touches.length === 1) {
            // Один палец
            const x = touches[0].clientX - rect.left;
            const y = touches[0].clientY - rect.top;
            lastX = x;
            lastY = y;
            isMovingDuringTap = false;
            startTapX = x;
            startTapY = y;

            // Отменяем предыдущий ожидающий тап
            if (tapTimeout) clearTimeout(tapTimeout);
            isTapPending = true;
            tapTimeout = setTimeout(() => {
                // Если не было движения и не было второго тапа — это одиночный тап
                if (isTapPending && !isMovingDuringTap) {
                    fetch('/click', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({button: 'left'})
                    }).catch(e => console.log(e));
                    statusDiv.textContent = '✅ левый клик (тап)';
                    setTimeout(() => statusDiv.textContent = '⚡ тап 1 палец → левый клик | 2 пальца → скролл', 500);
                }
                isTapPending = false;
                tapTimeout = null;
            }, 150);
        }
        else if (touches.length === 2) {
            // Два пальца — скролл
            // Отменяем возможный тап
            if (tapTimeout) clearTimeout(tapTimeout);
            isTapPending = false;
            twoFingerActive = true;
            const y1 = touches[0].clientY - rect.top;
            const y2 = touches[1].clientY - rect.top;
            twoFingerStartY = (y1 + y2) / 2;
            lastScrollY = twoFingerStartY;
            statusDiv.textContent = '📜 скролл (2 пальца)';
        }
    });

    touchpad.addEventListener('touchmove', function(e) {
        e.preventDefault();
        const rect = touchpad.getBoundingClientRect();
        const touches = e.touches;

        if (touches.length === 1 && lastX !== null && !twoFingerActive) {
            // Один палец — движение мыши
            const currentX = touches[0].clientX - rect.left;
            const currentY = touches[0].clientY - rect.top;

            // Если палец сместился больше чем на 5 пикселей — считаем что это движение, а не тап
            if (Math.hypot(currentX - startTapX, currentY - startTapY) > 5) {
                isMovingDuringTap = true;
                if (isTapPending) {
                    clearTimeout(tapTimeout);
                    isTapPending = false;
                }
            }

            const now = Date.now();
            if (now - lastSendTime < MIN_INTERVAL) return;

            let dx = currentX - lastX;
            let dy = currentY - lastY;

            if (dx !== 0 || dy !== 0) {
                fetch('/move', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({dx: dx, dy: dy})
                }).catch(e => console.log(e));

                lastX = currentX;
                lastY = currentY;
                lastSendTime = now;
                statusDiv.textContent = '🖱️ движение мыши';
                setTimeout(() => {
                    if (!twoFingerActive && lastX !== null)
                        statusDiv.textContent = '⚡ тап 1 палец → левый клик | 2 пальца → скролл';
                }, 200);
            }
        }
        else if (touches.length === 2 && twoFingerActive) {
            // Два пальца — скролл
            const y1 = touches[0].clientY - rect.top;
            const y2 = touches[1].clientY - rect.top;
            const avgY = (y1 + y2) / 2;
            let delta = avgY - lastScrollY;
            if (Math.abs(delta) >= 1) {
                // Отправляем скролл (знак: вверх отрицательный, вниз положительный)
                let scrollAmount = -delta;  // чтобы движение пальцев вниз скроллило вниз
                if (scrollAmount !== 0) {
                    fetch('/scroll', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({delta: scrollAmount})
                    }).catch(e => console.log(e));
                }
                lastScrollY = avgY;
                statusDiv.textContent = '📜 скролл';
                setTimeout(() => {
                    if (twoFingerActive) statusDiv.textContent = '📜 скролл (2 пальца)';
                }, 100);
            }
        }
    });

    touchpad.addEventListener('touchend', function(e) {
        const remainingTouches = e.touches.length;
        if (remainingTouches === 0) {
            // Все пальцы убраны
            if (tapTimeout) {
                // Если таймер ещё не сработал, не отменяем его — он сам отправит клик через 150ms
                // Но нужно сбросить флаги
                // Ничего не делаем, таймер сам решит
            }
            lastX = null;
            lastY = null;
            twoFingerActive = false;
            twoFingerStartY = null;
            lastScrollY = null;
            isMovingDuringTap = false;
            statusDiv.textContent = '⚡ тап 1 палец → левый клик | 2 пальца → скролл';
        }
        else if (remainingTouches === 1 && twoFingerActive) {
            // Было два пальца, один убрали — прекращаем скролл, но не начинаем движение
            twoFingerActive = false;
            twoFingerStartY = null;
            lastScrollY = null;
            // Не сбрасываем lastX/lastY, чтобы не начать движение резко
            statusDiv.textContent = '⚡ тап 1 палец → левый клик | 2 пальца → скролл';
        }
    });

    // Двойной тап (два быстрых касания одним пальцем)
    let doubleTapTimer = null;
    let doubleTapCount = 0;
    touchpad.addEventListener('touchstart', function(e) {
        if (e.touches.length === 1) {
            doubleTapCount++;
            if (doubleTapCount === 1) {
                doubleTapTimer = setTimeout(() => {
                    doubleTapCount = 0;
                }, 250);
            } else if (doubleTapCount === 2) {
                clearTimeout(doubleTapTimer);
                doubleTapCount = 0;
                // Двойной тап — правый клик
                fetch('/click', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({button: 'right'})
                }).catch(e => console.log(e));
                statusDiv.textContent = '🔽 правый клик (двойной тап)';
                setTimeout(() => statusDiv.textContent = '⚡ тап 1 палец → левый клик | 2 пальца → скролл', 500);
                // Отменяем одиночный тап
                if (tapTimeout) clearTimeout(tapTimeout);
                isTapPending = false;
            }
        }
    });

    // Кнопки как резерв
    document.getElementById('leftBtn').addEventListener('click', () => {
        fetch('/click', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({button: 'left'})});
        statusDiv.textContent = '🖱️ левый клик (кнопка)';
        setTimeout(() => statusDiv.textContent = '⚡ тап 1 палец → левый клик | 2 пальца → скролл', 500);
    });
    document.getElementById('rightBtn').addEventListener('click', () => {
        fetch('/click', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({button: 'right'})});
        statusDiv.textContent = '🔽 правый клик (кнопка)';
        setTimeout(() => statusDiv.textContent = '⚡ тап 1 палец → левый клик | 2 пальца → скролл', 500);
    });
</script>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/move', methods=['POST'])
def move():
    data = request.get_json()
    dx = data.get('dx', 0)
    dy = data.get('dy', 0)
    move_queue.append((dx, dy))
    return 'ok'

@app.route('/scroll', methods=['POST'])
def scroll():
    data = request.get_json()
    delta = data.get('delta', 0)
    if delta != 0:
        scroll_queue.append(delta)
    return 'ok'

@app.route('/click', methods=['POST'])
def click():
    data = request.get_json()
    if data.get('button') == 'left':
        click_left()
    else:
        click_right()
    return 'ok'

if __name__ == '__main__':
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    ip = s.getsockname()[0]
    s.close()
    print(f'\n→ Откройте на телефоне: http://{ip}:9898\n')
    print('Жесты:')
    print('  • Один палец (тап без движения) → левый клик')
    print('  • Двойной тап → правый клик')
    print('  • Движение одним пальцем → перемещение мыши')
    print('  • Два пальца вертикально → скролл')
    app.run(host='0.0.0.0', port=9898, debug=False, threaded=True)
